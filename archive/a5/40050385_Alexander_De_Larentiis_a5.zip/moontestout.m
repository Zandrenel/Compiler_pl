   align   
   entry   
   j   scope4
stop   hlt   
scope4       

   sub   r1,r1,r1
   addi   r1,r1,21
   sw   symbol10(r0),r1

   sub   r1,r1,r1
   addi   r1,r1,3
   sw   symb65(r0),r1
   sub   r1,r1,r1
   addi   r1,r1,8
   sw   symb66(r0),r1
   lw   r1,symb65(r0)
   lw   r2,symb66(r0)
   add   r3,r1,r2
   sw   symb64(r0),r3
   lw   r1,symb64(r0)
   sw   symbol11(r0),r1


   sub   r1,r1,r1
   addi   r1,r1,7
   sw   symb69(r0),r1
   sub   r1,r1,r1
   addi   r1,r1,2
   sw   symb70(r0),r1
   lw   r1,symb69(r0)
   lw   r2,symb70(r0)
   add   r3,r1,r2
   sw   symb68(r0),r3

   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb76(r0),r1

   sub   r1,r1,r1
   addi   r1,r1,2
   sw   symb72(r0),r1
   sub   r1,r1,r1
   addi   r1,r1,9
   sw   symb73(r0),r1
   lw   r1,symb72(r0)
   lw   r2,symb73(r0)
   add   r3,r1,r2
   sw   symb71(r0),r3
   lw   r1,symb76(r0)
   lw   r2,symb71(r0)
   add   r3,r1,r2
   sw   symb75(r0),r3
   lw   r1,symb68(r0)
   lw   r2,symb75(r0)
   add   r3,r1,r2
   sw   symb77(r0),r3
   lw   r1,symb77(r0)
   sw   symbol12(r0),r1
   j   stop
symbol10   res   4
symb65   res   4
symb66   res   4
symb64   res   4
symbol11   res   4
symb69   res   4
symb70   res   4
symb68   res   4
symb72   res   4
symb73   res   4
symb71   res   4
symb76   res   4
symb75   res   4
symb77   res   4
symbol12   res   4
symb79   res   4
symb80   res   4
symb78   res   4
symb83   res   4
symb84   res   4
symb82   res   4
