   align   
   entry   
   j   scope17
stop   hlt   
scope17       %,Free Function,"main"

   sub   r1,r1,r1
   addi   r1,r1,21
   sw   symbol48(r0),r1


   sub   r1,r1,r1
   addi   r1,r1,4
   sw   symb163(r0),r1
   lw   r1,symbol48(r0)
   lw   r2,symb163(r0)
   add   r3,r1,r2
   sw   symb162(r0),r3
   lw   r1,symb162(r0)
   sw   symbol49(r0),r1


   sub   r1,r1,r1
   addi   r1,r1,4
   sw   symb165(r0),r1
   lw   r1,symbol48(r0)
   lw   r2,symb165(r0)
   add   r3,r1,r2
   sw   symb164(r0),r3
   lw   r1,symb164(r0)
   sw   symbol50(r0),r1



   sub   r1,r1,r1
   addi   r1,r1,4
   sw   symb167(r0),r1
   lw   r1,symbol48(r0)
   lw   r2,symb167(r0)
   add   r3,r1,r2
   sw   symb166(r0),r3
   sub   r1,r1,r1
   addi   r1,r1,2
   sw   symb169(r0),r1
   lw   r1,symb166(r0)
   lw   r2,symb169(r0)
   mul   r3,r1,r2
   sw   symb168(r0),r3
   lw   r1,symb168(r0)
   sw   symbol51(r0),r1



   sub   r1,r1,r1
   addi   r1,r1,3
   sw   symb174(r0),r1

   sub   r1,r1,r1
   addi   r1,r1,2
   sw   symb171(r0),r1
   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb172(r0),r1
   lw   r1,symb171(r0)
   lw   r2,symb172(r0)
   sub   r3,r1,r2
   sw   symb170(r0),r3
   lw   r1,symb174(r0)
   lw   r2,symb170(r0)
   sub   r3,r1,r2
   sw   symb173(r0),r3
   lw   r1,symbol48(r0)
   lw   r2,symb173(r0)
   add   r3,r1,r2
   sw   symb175(r0),r3
   lw   r1,symb175(r0)
   sw   symbol52(r0),r1



   lw   r1,symbol51(r0)
   lw   r2,symbol51(r0)
   add   r3,r1,r2
   sw   symb176(r0),r3
   lw   r1,symb176(r0)
   sw   symbol53(r0),r1


   sub   r1,r1,r1
   addi   r1,r1,7
   sw   symb178(r0),r1
   sub   r1,r1,r1
   addi   r1,r1,2
   sw   symb179(r0),r1
   lw   r1,symb178(r0)
   lw   r2,symb179(r0)
   sub   r3,r1,r2
   sw   symb177(r0),r3

   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb184(r0),r1

   sub   r1,r1,r1
   addi   r1,r1,2
   sw   symb181(r0),r1
   sub   r1,r1,r1
   addi   r1,r1,9
   sw   symb182(r0),r1
   lw   r1,symb181(r0)
   lw   r2,symb182(r0)
   mul   r3,r1,r2
   sw   symb180(r0),r3
   lw   r1,symb184(r0)
   lw   r2,symb180(r0)
   sub   r3,r1,r2
   sw   symb183(r0),r3
   lw   r1,symb177(r0)
   lw   r2,symb183(r0)
   mul   r3,r1,r2
   sw   symb185(r0),r3
   lw   r1,symb185(r0)
   sw   symbol54(r0),r1

   lw   r1,symbol54(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1

   lw   r1,symbol51(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1

   lw   r1,symbol53(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1

   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb187(r0),r1
   sub   r1,r1,r1
   addi   r1,r1,3
   sw   symb188(r0),r1
   lw   r1,symb187(r0)
   lw   r2,symb188(r0)
   ceq   r3,r1,r2
   sw   symb186(r0),r3
   lw   r1,symb186(r0)
   bnz   r1,if16
   j   if18
if16        

   lw   r1,symbol53(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1
   j   if18
if17        
if18        
loop7       


   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb190(r0),r1
   sub   r1,r1,r1
   addi   r1,r1,3
   sw   symb191(r0),r1
   lw   r1,symb190(r0)
   lw   r2,symb191(r0)
   add   r3,r1,r2
   sw   symb189(r0),r3

   lw   r1,symb189(r0)
   lw   r2,symbol48(r0)
   cge   r3,r1,r2
   sw   symb192(r0),r3
   lw   r1,symb192(r0)
   bnz   r1,while7

   lw   r1,symbol48(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1


   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb194(r0),r1
   lw   r1,symbol48(r0)
   lw   r2,symb194(r0)
   sub   r3,r1,r2
   sw   symb193(r0),r3
   lw   r1,symb193(r0)
   sw   symbol48(r0),r1

   lw   r1,symbol48(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1


   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb194(r0),r1
   lw   r1,symbol48(r0)
   lw   r2,symb194(r0)
   sub   r3,r1,r2
   sw   symb193(r0),r3
   lw   r1,symb193(r0)
   sw   symbol48(r0),r1
   j   loop7
while7       


   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb196(r0),r1
   lw   r1,symbol53(r0)
   lw   r2,symb196(r0)
   add   r3,r1,r2
   sw   symb195(r0),r3
   lw   r1,symb195(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1
   j   stop
buf   res   20
symbol48   res   4
symb163   res   4
symb162   res   4
symbol49   res   4
symb165   res   4
symb164   res   4
symbol50   res   4
symb167   res   4
symb166   res   4
symb169   res   4
symb168   res   4
symbol51   res   4
symb171   res   4
symb172   res   4
symb170   res   4
symb174   res   4
symb173   res   4
symb175   res   4
symbol52   res   4
symb176   res   4
symbol53   res   4
symb178   res   4
symb179   res   4
symb177   res   4
symb181   res   4
symb182   res   4
symb180   res   4
symb184   res   4
symb183   res   4
symb185   res   4
symbol54   res   4
symb187   res   4
symb188   res   4
symb186   res   4
symb190   res   4
symb191   res   4
symb189   res   4
symb192   res   4
symb194   res   4
symb193   res   4
symb196   res   4
symb195   res   4
