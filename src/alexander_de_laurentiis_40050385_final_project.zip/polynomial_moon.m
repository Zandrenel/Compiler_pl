   align   
   entry   
   j   scope16
stop   hlt   
scope11       %,Function,"evaluate",Scope,"POLYNOMIAL"

   jr   r15
scope12       %,Function,"evaluate",Scope,"QUADRATIC"

   jr   r15
scope13       %,Function,"build",Scope,"QUADRATIC"

   jr   r15
scope14       %,Function,"build",Scope,"LINEAR"



   jr   r15
scope15       %,Function,"evaluate",Scope,"LINEAR"

   jr   r15
scope16       %,Free Function,"main"


   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symbol47(r0),r1
loop6       


   sub   r1,r1,r1
   addi   r1,r1,10
   sw   symb161(r0),r1
   lw   r1,symbol47(r0)
   lw   r2,symb161(r0)
   cle   r3,r1,r2
   sw   symb160(r0),r3
   lw   r1,symb160(r0)
   bnz   r1,while6

   lw   r1,symbol47(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1



   lw   r1,symbol47(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1


   j   loop6
while6       
   j   stop
buf   res   20
symbol38   res   8
symbol39   res   8
symb156   res   4
symb157   res   4
symb158   res   4
symb159   res   4
symbol40   res   40
symbol41   res   8
symbol42   res   8
symbol43   res   16
symbol44   res   8
symbol45   res   16
symbol46   res   40
symbol47   res   4
symb161   res   4
symb160   res   4
