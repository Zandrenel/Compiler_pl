   align   
   entry   
   j   scope206
stop   hlt   
scope206       %,Free Function,"main"

   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb223(r0),r1
   sub   r1,r1,r1
   addi   r1,r1,4
   sw   symb224(r0),r1
   lw   r1,symb223(r0)
   lw   r2,symb224(r0)
   add   r3,r1,r2
   sw   symb222(r0),r3
   lw   r1,symb222(r0)
   sw   symbol63(r0),r1

   lw   r1,symbol63(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1
   j   stop
buf   res   20
symb223   res   4
symb224   res   4
symb222   res   4
symbol63   res   4
