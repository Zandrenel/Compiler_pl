   align   
   entry   
   j   scope18
stop   hlt   
scope18       %,Free Function,"main"

   sub   r1,r1,r1
   addi   r1,r1,21
   sw   symbol55(r0),r1


   sub   r1,r1,r1
   addi   r1,r1,4
   sw   symb198(r0),r1
   lw   r1,symbol55(r0)
   lw   r2,symb198(r0)
   add   r3,r1,r2
   sw   symb197(r0),r3
   lw   r1,symb197(r0)
   sw   symbol56(r0),r1


   sub   r1,r1,r1
   addi   r1,r1,4
   sw   symb200(r0),r1
   lw   r1,symbol55(r0)
   lw   r2,symb200(r0)
   add   r3,r1,r2
   sw   symb199(r0),r3
   lw   r1,symb199(r0)
   sw   symbol57(r0),r1



   sub   r1,r1,r1
   addi   r1,r1,3
   sw   symb205(r0),r1

   sub   r1,r1,r1
   addi   r1,r1,2
   sw   symb202(r0),r1
   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb203(r0),r1
   lw   r1,symb202(r0)
   lw   r2,symb203(r0)
   sub   r3,r1,r2
   sw   symb201(r0),r3
   lw   r1,symb205(r0)
   lw   r2,symb201(r0)
   sub   r3,r1,r2
   sw   symb204(r0),r3
   lw   r1,symbol55(r0)
   lw   r2,symb204(r0)
   add   r3,r1,r2
   sw   symb206(r0),r3
   lw   r1,symb206(r0)
   sw   symbol58(r0),r1



   lw   r1,symbol59(r0)
   lw   r2,symbol59(r0)
   add   r3,r1,r2
   sw   symb207(r0),r3
   lw   r1,symb207(r0)
   sw   symbol60(r0),r1

   lw   r1,symbol61(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1

   lw   r1,symbol59(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1

   lw   r1,symbol60(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1

   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb209(r0),r1
   sub   r1,r1,r1
   addi   r1,r1,3
   sw   symb210(r0),r1
   lw   r1,symb209(r0)
   lw   r2,symb210(r0)
   ceq   r3,r1,r2
   sw   symb208(r0),r3
   lw   r1,symb208(r0)
   bnz   r1,if19
   j   if21
if19        

   lw   r1,symbol60(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1
   j   if21
if20        
if21        
loop8       


   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb212(r0),r1
   sub   r1,r1,r1
   addi   r1,r1,3
   sw   symb213(r0),r1
   lw   r1,symb212(r0)
   lw   r2,symb213(r0)
   add   r3,r1,r2
   sw   symb211(r0),r3

   lw   r1,symb211(r0)
   lw   r2,symbol55(r0)
   cge   r3,r1,r2
   sw   symb214(r0),r3
   lw   r1,symb214(r0)
   bnz   r1,while8

   lw   r1,symbol55(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1


   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb216(r0),r1
   lw   r1,symbol55(r0)
   lw   r2,symb216(r0)
   sub   r3,r1,r2
   sw   symb215(r0),r3
   lw   r1,symb215(r0)
   sw   symbol55(r0),r1

   lw   r1,symbol55(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1


   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb216(r0),r1
   lw   r1,symbol55(r0)
   lw   r2,symb216(r0)
   sub   r3,r1,r2
   sw   symb215(r0),r3
   lw   r1,symb215(r0)
   sw   symbol55(r0),r1
   j   loop8
while8       


   sub   r1,r1,r1
   addi   r1,r1,1
   sw   symb218(r0),r1
   lw   r1,symbol60(r0)
   lw   r2,symb218(r0)
   add   r3,r1,r2
   sw   symb217(r0),r3
   lw   r1,symb217(r0)
   jl   r15,putint
   sub   r1,r1,r1
   addi   r1,r1,10
   putc   r1
   j   stop
buf   res   20
symbol55   res   4
symb198   res   4
symb197   res   4
symbol56   res   4
symb200   res   4
symb199   res   4
symbol57   res   4
symb202   res   4
symb203   res   4
symb201   res   4
symb205   res   4
symb204   res   4
symb206   res   4
symbol58   res   4
symbol59   res   4
symb207   res   4
symbol60   res   4
symbol61   res   4
symb209   res   4
symb210   res   4
symb208   res   4
symb212   res   4
symb213   res   4
symb211   res   4
symb214   res   4
symb216   res   4
symb215   res   4
symb218   res   4
symb217   res   4
